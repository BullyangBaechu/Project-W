#include "pch.h"
#include "Stage01Level.h"

Stage01Level::Stage01Level()
{
}

Stage01Level::~Stage01Level()
{
}

void Stage01Level::Enter()
{
}

void Stage01Level::Exit()
{
}