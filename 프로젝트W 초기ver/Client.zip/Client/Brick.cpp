#include "pch.h"
#include "Brick.h"
#include "Engine.h"
#include "RigidBody.h"

#include "Actor.h"
#include "Collider.h"
#include "TimeMgr.h"
#include "Camera.h"
#include "Player.h"
#include "AssetMgr.h"
#include "Ground.h"

#include "EffectActor.h"
#include "LevelMgr.h"
#include "Level.h"

void Brick::Init(int type)
{
	m_MaxHP = type;
	m_CurHP = type;

	IsHit = false;

	SetScale(Vec2(100.f, 150.f));
	SetName(L"Brick_" + to_wstring(type));

	wstring key = L"brickLv" + to_wstring(type);
	wstring path = L"Texture\\brickLv" + to_wstring(type) + L".bmp";

	m_Tex = AssetMgr::GetInst()->LoadTexture(key, path);

	
	m_Collider = AddComponent(new Collider);
	//m_Collider->SetScale(Vec2(100.f, 100.f)); // �׽�Ʈ ��
	m_Collider->SetScale(GetScale()); //-> �ؽ��� ������ �̰� ����

	m_Collider->SetOffset(Vec2(0.f, 0.f));


	m_RigidBody = AddComponent<RigidBody>(new RigidBody);

	// �ı� ��
	m_DestructionTimer = 0.3f;
	m_bDestroyed = false;
	//m_DestoryTex = AssetMgr::GetInst()->LoadTexture(L"bomb", L"Texture\\explosion_effect_whitebg_120x120.bmp");

}

void Brick::Hit(int dmg)
{
	m_CurHP -= dmg;
	if (m_CurHP == 0)
	{
		StartDestroy();
		Destroy();
	}
		//Destroy();
}

void Brick::StartDestroy()
{
	if (m_bDestroyed)
		return;

	m_bDestroyed = true;
	m_DestructionTimer = 0.3f;

	EffectActor* pEffect = new EffectActor;


	pEffect->SetEffect(AssetMgr::GetInst()->FindTexture(L"explosion2"), 0.3f, nullptr); // ���� �����Ϸ��� nullptr
	pEffect->SetPos(GetPos());
	Level* pLevel = LevelMgr::GetInst()->GetCurrentLevel();
	pLevel->AddObject(ACTOR_TYPE::EFFECT, pEffect);

}

void Brick::Tick()
{

	//OutputDebugString(L"[Brick] Tick ȣ���\n");

	if (m_RigidBody == nullptr)
		return;

	m_RigidBody->SetGround(false);
	Vec2 BrickPos = GetPos();
	
	if (m_bDestroyed)
	{
		m_DestructionTimer -= DT;
		if (m_DestructionTimer <= 0.f)
		{
			Destroy();
		}
		return;
	}
	float HalfHeight = m_Collider->GetScale().y / 2.f;


	// ������ ���߿� �ִٸ�
	if (BrickPos.y + HalfHeight < GROUND_Y - 48.f)
	{
		// ī�޶� ���� ���� �̵��ϴ� ����
		float CamSpeed = Camera::GetInst()->GetCamSpeed();
		BrickPos.x += CamSpeed * DT; // �ʴ� 300 �ӵ� 
		SetPos(BrickPos);
		m_RigidBody->SetGround(false);
	}
	// ������ �ٴڿ� ��� �Ǹ�
	else
	{
		Vec2 Pos = GetPos();
		Pos.y = GROUND_Y - HalfHeight - 48.f;
		SetPos(Pos);

		m_RigidBody->SetGround(true);
	}

	IsHit = false;
}

void Brick::Render(HDC _dc)
{
	
	if (m_Tex)
	{
		Vec2 renderPos = GetRenderPos();
		float w = m_Tex->GetWidth();
		float h = m_Tex->GetHeight();

		TransparentBlt(_dc,
			(int)(renderPos.x - w / 2.f),
			(int)(renderPos.y - h / 2.f),
			(int)w,
			(int)h,
			m_Tex->GetDC(),
			0, 0,
			(int)w,
			(int)h,
			RGB(255, 255, 255)); // ���� ����
	}
	
	Actor::Render(_dc); // �θ��� ����� ������ ȣ��
}

// ���� �ǰ� ���� �浹 ����
void Brick::BeginOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider)
{
	if (_OtherCollider->GetName() == L"AttackBox")
	{
		// �̹� �ǰ� �����̶�� �׳� return
		if (IsHit)
			return;
		
		// AttackBox�� Collider �� �ᱹ player�� Attack �Լ��� ������ Collider �̹Ƿ� attacker�� player�� dynamiccast ���ش�.
		Actor* attacker = _OtherCollider->GetOwner();
		Player* pPlayer = dynamic_cast<Player*>(attacker);
		if (pPlayer)
		{
			IsHit = true;
			int dmg = pPlayer->GetPlayerDmg();
			Hit(dmg);
		}
	}
	
}

// �ʿ��ϸ� �� ����
void Brick::EndOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider)
{
}
