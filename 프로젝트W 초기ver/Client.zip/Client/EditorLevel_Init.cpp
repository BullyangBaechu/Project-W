#include "pch.h"
#include "EditorLevel.h"

#include "PathMgr.h"
#include "AssetMgr.h"
#include "Sprite.h"
#include "LevelMgr.h"

#include "TileActor.h"
#include "TileMap.h"

#include "Engine.h"
#include "KeyMgr.h"
#include "resource.h"

#include "Camera.h"

#include "UI.h"
#include "BtnUI.h"
#include "PanelUI.h"

void EditorLevel::CreateEditorUI()
{
	{
		// PanelUI ����
		PanelUI* pPanel = new PanelUI;
		pPanel->SetPos(Vec2(780.f, 50.f));
		pPanel->SetScale(Vec2(400.f, 500.f));
		AddObject(ACTOR_TYPE::UI, pPanel);

		// SaveButton �� PanelUI �ڽ����� �߰�
		BtnUI* pBtnUI = new BtnUI;
		pBtnUI->SetName(L"Save Button");
		pBtnUI->SetPos(Vec2(10.f, 10.f));

		pBtnUI->SetBaseImage(AssetMgr::GetInst()->LoadTexture(L"BtnImage", L"Texture\\Start.png"));
		pBtnUI->SetHoverImage(nullptr);
		pBtnUI->SetPressedImage(nullptr);
		void PressSaveBtn();
		pBtnUI->SetCallBack(&PressSaveBtn);

		pPanel->AddChildUI(pBtnUI);

		pBtnUI = new BtnUI;
		pBtnUI->SetName(L"Load Button");
		pBtnUI->SetBaseImage(AssetMgr::GetInst()->LoadTexture(L"BtnImage", L"Texture\\Start.png"));
		pBtnUI->SetHoverImage(nullptr);
		pBtnUI->SetPressedImage(nullptr);
		pBtnUI->SetPos(Vec2(400.f - pBtnUI->GetScale().x - 10, 10.f));
		void PressLoadBtn();
		pBtnUI->SetCallBack(&PressLoadBtn);
		pPanel->AddChildUI(pBtnUI);
	}

	{
		// PanelUI ����
		PanelUI* pPanel = new PanelUI;
		pPanel->SetPos(Vec2(280.f, 50.f));
		pPanel->SetScale(Vec2(400.f, 500.f));
		AddObject(ACTOR_TYPE::UI, pPanel);

		// SaveButton �� PanelUI �ڽ����� �߰�
		BtnUI* pBtnUI = new BtnUI;
		pBtnUI->SetName(L"Save Button");
		pBtnUI->SetPos(Vec2(10.f, 10.f));

		pBtnUI->SetBaseImage(AssetMgr::GetInst()->LoadTexture(L"BtnImage", L"Texture\\Start.png"));
		pBtnUI->SetHoverImage(nullptr);
		pBtnUI->SetPressedImage(nullptr);
		void PressSaveBtn();
		pBtnUI->SetCallBack(&PressSaveBtn);

		pPanel->AddChildUI(pBtnUI);

		pBtnUI = new BtnUI;
		pBtnUI->SetName(L"Load Button");
		pBtnUI->SetBaseImage(AssetMgr::GetInst()->LoadTexture(L"BtnImage", L"Texture\\Start.png"));
		pBtnUI->SetHoverImage(nullptr);
		pBtnUI->SetPressedImage(nullptr);
		pBtnUI->SetPos(Vec2(400.f - pBtnUI->GetScale().x - 10, 10.f));
		void PressLoadBtn();
		pBtnUI->SetCallBack(&PressLoadBtn);
		pPanel->AddChildUI(pBtnUI);
	}
}


// ========
// CallBack
// ========
void PressSaveBtn()
{
	// ���� ������ EditorLevel �� �ƴ϶��
	EditorLevel* pLevel = dynamic_cast<EditorLevel*>(LevelMgr::GetInst()->GetCurrentLevel());
	if (nullptr == pLevel)
		return;

	TileActor* pActor = pLevel->GetTileActor();
	TileMap* pTileMap = pActor->GetComponent<TileMap>();

	// Ž���� ���̾�α� ����
	// ���� ��� ���ڿ�
	wchar_t szFilePath[255] = {};

	OPENFILENAME Desc = {};
	Desc.lStructSize = sizeof(OPENFILENAME);
	Desc.hwndOwner = nullptr;
	Desc.lpstrFile = szFilePath;	// ���������� ���� ��θ� �޾Ƴ� ������
	Desc.nMaxFile = 255;
	Desc.lpstrFilter = L"TileMap\0*.tilemap\0ALL\0*.*";
	Desc.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
	Desc.lpstrInitialDir = PathMgr::GetInst()->GetContentPath();

	if (GetSaveFileName(&Desc))
	{
		// Content ���� ������ΰ� �����Ǿ����� Ȯ��
		wstring strFilePath = szFilePath;
		if (wstring::npos == strFilePath.find(PathMgr::GetInst()->GetContentPath()))
			return;

		// �պκ� ContentPath ������, �޺κ� ����θ� �߶�
		int ContentPathLen = wcslen(PathMgr::GetInst()->GetContentPath());
		wstring RelativePath = strFilePath.substr(ContentPathLen, strFilePath.length());

		// ����
		pTileMap->Save(RelativePath);
	}
}

void PressLoadBtn()
{
	// ���� ������ EditorLevel �� �ƴ϶��
	EditorLevel* pLevel = dynamic_cast<EditorLevel*>(LevelMgr::GetInst()->GetCurrentLevel());
	if (nullptr == pLevel)
		return;

	TileActor* pActor = pLevel->GetTileActor();
	TileMap* pTileMap = pActor->GetComponent<TileMap>();

	// Ž���� ���̾�α�
	// ���� ��� ���ڿ�
	wchar_t szFilePath[255] = {};

	OPENFILENAME Desc = {};

	Desc.lStructSize = sizeof(OPENFILENAME);
	Desc.hwndOwner = nullptr;
	Desc.lpstrFile = szFilePath;
	Desc.nMaxFile = 255;
	Desc.lpstrFilter = L"TileMap\0*.tilemap\0ALL\0*.*";
	Desc.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
	Desc.lpstrInitialDir = PathMgr::GetInst()->GetContentPath();

	if (GetOpenFileName(&Desc))
	{
		// Content ���� ������ΰ� �����Ǿ����� Ȯ��
		wstring strFilePath = szFilePath;
		if (wstring::npos == strFilePath.find(PathMgr::GetInst()->GetContentPath()))
			return;

		// �պκ� ContentPath ������, �޺κ� ����θ� �߶�
		int ContentPathLen = wcslen(PathMgr::GetInst()->GetContentPath());
		wstring RelativePath = strFilePath.substr(ContentPathLen, strFilePath.length());

		pTileMap->Load(RelativePath);
	}
}