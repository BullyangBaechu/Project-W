#pragma once

#include "define.h"
#include "enum.h"
#include "struct.h"
#include "func.h"
#include "SelectGDI.h"

