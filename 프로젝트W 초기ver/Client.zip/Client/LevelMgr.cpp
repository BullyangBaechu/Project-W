#include "pch.h"
#include "LevelMgr.h"
#include "Actor.h"

#include "StartLevel.h"
#include "RunningLevel.h"
#include "EditorLevel.h"
#include "TestLevel.h"
#include "InfiniteLevel.h"
#include "GameOverLevel.h"
#include "GameClearLevel.h"
#include "HelpLevel.h"
#include "Camera.h"



LevelMgr::LevelMgr()
	: m_CurLevel(nullptr)
	, m_AllLevel{}
{

}

LevelMgr::~LevelMgr()
{
	Delete_Arr(m_AllLevel);
}

void LevelMgr::Init()
{
	m_AllLevel[(UINT)LEVEL_TYPE::START] = new StartLevel;
	m_AllLevel[(UINT)LEVEL_TYPE::RUNNING] = new RunningLevel;
	m_AllLevel[(UINT)LEVEL_TYPE::EDITOR] = new EditorLevel;
	m_AllLevel[(UINT)LEVEL_TYPE::TEST] = new TestLevel;
	m_AllLevel[(UINT)LEVEL_TYPE::INFINITYMODE] = new InfiniteLevel;
	m_AllLevel[(UINT)LEVEL_TYPE::GAMEOVER] = new GameOverLevel;
	m_AllLevel[(UINT)LEVEL_TYPE::GAMECLEAR] = new GameClearLevel;
	m_AllLevel[(UINT)LEVEL_TYPE::HELP] = new HelpLevel;

	::ChangeLevel(LEVEL_TYPE::START);
}

void LevelMgr::Progress()
{
	if (nullptr == m_CurLevel)
		return;

	// ī�޶� ���� ����
	Camera::GetInst()->Tick();

	// 1 �����ӵ��� Level �ȿ� �ִ� Actor �� �� ���� �����Ѵ�.
	m_CurLevel->Tick();

	// Actor ���� �� ���� ������ �� ��, �ļ���ġ
	m_CurLevel->FinalTick();
}

Actor* LevelMgr::FindActorByName(const wstring& _Name)
{
	return m_CurLevel->FindActorByName(_Name);
}

Actor* LevelMgr::FindActorByName(ACTOR_TYPE _Type, const wstring& _Name)
{
	return  m_CurLevel->FindActorByName(_Type, _Name);
}

Actor* LevelMgr::GetPlayer()
{
	return m_CurLevel->GetPlayer();
}

void LevelMgr::ChangeLevel(LEVEL_TYPE _Next)
{

	assert(m_AllLevel[(UINT)_Next] != m_CurLevel);

	if (m_CurLevel)
		m_CurLevel->Exit();

	// ���� ������ ��ü
	m_CurLevel = m_AllLevel[(UINT)_Next];	

	// ��ü�� �ʱ�ȭ �۾�
	m_CurLevel->Enter();

	// �����ȿ� �ִ� Actor �� Begin ȣ��
	m_CurLevel->Begin();
}
