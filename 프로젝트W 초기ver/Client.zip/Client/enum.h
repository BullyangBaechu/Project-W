#pragma once

enum class LEVEL_TYPE
{
	START,
	RUNNING,
	EDITOR,
	TEST,
	INFINITYMODE,
	GAMEOVER,
	GAMECLEAR,
	HELP,

	END,
};

enum class PEN_TYPE
{
	RED,
	GREEN,
	BLUE,	
	GRAY,

	END,
};

enum class BRUSH_TYPE
{
	GREEN,
	RED,
	GRAY,
	BLUE,	

	END,
};

enum class ASSET_TYPE
{
	TEXTURE,
	SOUND,
	SPRITE,
	FLIPBOOK,

	END,
};

enum class COMPONENT_TYPE
{
	COLLIDER,
	FLIPBOOK_PLAYER,
	RIGIDBODY,
	STATE_MACHINE,
	TILEMAP,

	END,
};



enum class DEBUG_SHAPE
{
	RECT,
	CIRCLE,
	LINE,
};


enum class ACTOR_TYPE
{
	DEFAULT,
	BACKGROUND,
	TILE,
	PLATFORM,
	PLAYER,
	ENERMY,
	PLAYER_PROJECTILE,
	ENERMY_PROJECTILE,
	FORCE,
	SPAWNER,
	BRICK,
	BOMB,
	SLOWZONE,
	EFFECT,
	ESCAPE,



	UI = 31,
	END = 32
};


enum class TASK_TYPE
{
	CREATE_ACTOR,
	DESTROY_ACTOR,
	DELETE_ACTOR,
	CHANGE_LEVEL,

};

enum class STAGEMODE
{
	RUN,
	INFINITERUN,
	CHALLENGE,

};