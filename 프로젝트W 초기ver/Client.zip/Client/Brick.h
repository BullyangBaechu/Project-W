#pragma once
#include "Actor.h"
#include "Collider.h"
#include "CollisionMgr.h"
#include "Texture.h"

class Brick :
    public Actor
{
private :
    int m_MaxHP;            // ���� �ִ� ü��
    int m_CurHP;            // ���� ���� ü��

    Texture* m_Tex = nullptr;


    class Collider*     m_Collider;
    class RigidBody*    m_RigidBody;

    bool IsHit;             // �ǰ� ����

public:
    void Init(int type);    // type == ���� ����
    void Hit(int dmg);      // ĳ���� dmg

    virtual void Tick() override;
    virtual void Render(HDC _dc) override;

    virtual void BeginOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider) override;
    virtual void EndOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider) override;

};

