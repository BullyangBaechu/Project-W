#pragma once

class Texture;

class RenderMgr
{
	SINGLE(RenderMgr)
private:
	Vec2				m_Resolution;

	HDC					m_DC;			// DeviceContext �ڵ�		
	Texture*			m_BBTex;		// ����ۿ� �ؽ���

	// ���� ����� ��, �귯��
	HPEN				m_Pen[(int)PEN_TYPE::END];
	HBRUSH				m_Brush[(int)BRUSH_TYPE::END];

	// DebugShape ����
	list<tDebugShape>	m_ShapeList;

public:
	int Init(Vec2 _Resoution);
	void Progress();

	HDC GetMainDC() { return m_DC; }
	HPEN GetPen(PEN_TYPE _Type) { return m_Pen[(int)_Type]; }
	HBRUSH GetBrush(BRUSH_TYPE _Type) { return m_Brush[(int)_Type]; }

	void AddDebugShape(tDebugShape _shape) { m_ShapeList.push_back(_shape); }

private:
	void DebugRender();
	int CreateBuffer();
	void CreateGDIObject();
};

