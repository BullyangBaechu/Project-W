#include "pch.h"
#include "GameOverLevel.h"
#include "AssetMgr.h"
#include "Engine.h"
#include "LevelMgr.h"
#include "KeyMgr.h"
#include "RunningLevel.h"
#include "Sound.h"

GameOverLevel::GameOverLevel()
{
	m_tex = AssetMgr::GetInst()->LoadTexture(L"GameOver", L"Texture\\GameOverFactory_1440x1080.bmp");
}

GameOverLevel::~GameOverLevel()
{
}

void GameOverLevel::Enter()
{
    //OutputDebugString(L"[DEBUG] GameOverLevel::Enter() ȣ���\n");
    m_bgm = AssetMgr::GetInst()->LoadSound(L"GameOverBGM", L"Sound\\GameOverBGM.wav");
    m_bgm->PlayToBGM(true);
}

void GameOverLevel::Tick()
{

    //Level::Tick();

    // ���� �����
    if (KEY_TAP(KEY::ENTER))
    {
        //OutputDebugString(L"[DEBUG] Enter ���� - RunningLevel�� ��ȯ �õ�\n");

        ChangeLevel(LEVEL_TYPE::RUNNING);
    }

    // GameStartScene���� ����
    if (KEY_TAP(KEY::ESC))
    {
        ChangeLevel(LEVEL_TYPE::START);
    }

}

void GameOverLevel::Exit()
{
}

void GameOverLevel::Render(HDC _dc)
{
    if (m_tex)
    {
        int texW = m_tex->GetWidth();
        int texH = m_tex->GetHeight();

        TransparentBlt(_dc,
            0, 0, texW, texH,     // ��� ��ġ�� ũ��
            m_tex->GetDC(),
            0, 0, texW, texH,     // ���� ��ġ�� ũ��
            RGB(255, 0, 255));    
    }


    // ��� Game Over �ؽ�Ʈ
    const wchar_t* gameOverText = L"GAME OVER";

    // ū ��Ʈ ���� (150pt ũ��, Impact)
    HFONT hTitleFont = CreateFont(
        150, 0, 0, 0,
        FW_HEAVY,                // ���� (HEAVY�� ���� �β���)
        FALSE, FALSE, FALSE,
        HANGUL_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY,
        DEFAULT_PITCH | FF_SWISS,
        L"Impact"
    );

    // ��Ʈ ����
    HFONT hOldFont = (HFONT)SelectObject(_dc, hTitleFont);

    // �ؽ�Ʈ ���� ���� (���� ����)
    SetTextColor(_dc, RGB(220, 30, 30));
    SetBkMode(_dc, TRANSPARENT);

    // �ؽ�Ʈ ũ�� ����
    SIZE textSize;
    GetTextExtentPoint32(_dc, gameOverText, wcslen(gameOverText), &textSize);

    // �߾� X ��ǥ ���
    int centerX = (1440 - textSize.cx) / 2;

    // Y ��ǥ�� ��� �߾����� 
    int posY = 50;

    // �ؽ�Ʈ ���
    TextOut(_dc, centerX, posY, gameOverText, wcslen(gameOverText));

    // ��Ʈ ���� �� ����
    SelectObject(_dc, hOldFont);
    ::DeleteObject(hTitleFont);



    // === �ϴ� �ȳ����� ===
    const wchar_t* retryText = L"�絵�� : Enter";
    const wchar_t* exitText = L"������ : ESC";

    HFONT hInfoFont = CreateFont(
        30, 0, 0, 0, 
        FW_HEAVY,
        FALSE, FALSE, FALSE, 
        HANGUL_CHARSET,
        OUT_DEFAULT_PRECIS, 
        CLIP_DEFAULT_PRECIS, 
        DEFAULT_QUALITY,
        DEFAULT_PITCH | FF_SWISS,
        L"Impact");

    hOldFont = (HFONT)SelectObject(_dc, hInfoFont);

    SetTextColor(_dc, RGB(220, 30, 30));

    SIZE infoSize;
    GetTextExtentPoint32(_dc, retryText, wcslen(retryText), &infoSize);

    Vec2 res = Engine::GetInst()->GetResolution();

    int retryX = (1440 - infoSize.cx) / 2;
    int retryY = (int)(res.y * 0.8f); // �ϴ� ��ġ

    TextOut(_dc, retryX, retryY, retryText, wcslen(retryText));

    GetTextExtentPoint32(_dc, exitText, wcslen(exitText), &infoSize);

    int exitX = (1440 - infoSize.cx) / 2;
    int exitY = retryY + 40; // �ȳ��� �ٷ� �ؿ�

    TextOut(_dc, exitX, exitY, exitText, wcslen(exitText));

    SelectObject(_dc, hOldFont);
    ::DeleteObject(hInfoFont);
}


