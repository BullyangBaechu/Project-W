#pragma once
#include "Component.h"

enum class RIGIDBODY_MODE
{
    TOPVIEW,
    BELTSCROLL,
};

class RigidBody :
    public Component
{
private:
    float           m_Mass;         // ����
    Vec2            m_Force;        // ������ ��
    Vec2            m_Velocity;     // �ӷ� + �̵�����
    float           m_Friction;     // �������

    float           m_InitSpeed;    // �ʱ�ӷ� (���� -> �̵�) ���� ��ȯ�ɶ�
    float           m_MaxSpeed;     // �ִ�ӷ�

    bool            m_Move;

    RIGIDBODY_MODE  m_RigidBodyMode;

    // BeltScroll
    Vec2            m_GravityVelocity;
    float           m_MaxGravitySpeed;
    float           m_GravityAccel;
    bool            m_Ground;
    bool            IsJump;

    float           m_JumpSpeed; 
    int             m_MaxJumpStack;
    int             m_CurJumpStack;



public:
    GET_SET(float, Mass);
    GET_SET(Vec2, Force);
    GET_SET(Vec2, Velocity);
    GET_SET(float, Friction);
    GET_SET(float, InitSpeed);
    GET_SET(float, MaxSpeed);
    GET_SET(RIGIDBODY_MODE, RigidBodyMode);
    GET_SET(float, JumpSpeed);

    void SetGround(bool _Ground) 
    { 
        m_Ground = _Ground; 
        if (m_Ground)
        {
            m_CurJumpStack = 0;
        }
    }
    bool GetGround() { return m_Ground; }


    void AddForce(Vec2 _Force) { m_Force += _Force; }
    void Jump();

public:
    virtual void FinalTick() override;

    void CollisionResponse(Actor* pOwner, Actor* pOther);

private:
    //void TopView();
    void BeltScroll();


public:
    RigidBody();
    ~RigidBody();
};

