#pragma once
#include "Level.h"
#include "Texture.h"

class ProgressBarUI;
class Sound;

class RunningLevel :
    public Level
{
private:
    Texture* m_BGTex;               // ��� �ؽ���
    bool m_bFirstFrame = true;      // ù ������

    float m_GoalX;

    ProgressBarUI* m_ProgressBar;   // ���൵ ������ UI

    Sound* m_bgm;

    // GameOver ��
    bool m_IsGameOver;
    float m_GameOverTimer;
    
    // GameClear ��
    bool m_IsGameClear;
    float m_GameClearTimer;


public:
    virtual void Enter() override;
    virtual void Tick()  override;
    virtual void Exit()  override;

    virtual void Render(HDC _dc) override;


public:
    RunningLevel();
    ~RunningLevel();
};

