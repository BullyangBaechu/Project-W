#include "pch.h"
#include "State.h"

State::State()
	: m_Owner(nullptr)
{
}

State::~State()
{
}
