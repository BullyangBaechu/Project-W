#include "pch.h"
#include "HelpLevel.h"


HelpLevel::HelpLevel()
{
}

HelpLevel::~HelpLevel()
{
}

void HelpLevel::Enter()
{
}

void HelpLevel::Tick()
{
}

void HelpLevel::Exit()
{
}

void HelpLevel::Render(HDC _dc)
{
}


