#include "pch.h"
#include "Bomb.h"
#include "Engine.h"

#include "Collider.h"
#include "AssetMgr.h"

void Bomb::Init()
{
	SetName(L"Bomb");

	SetScale(Vec2(120.f, 120.f));
	m_Tex = AssetMgr::GetInst()->LoadTexture(L"bomb", L"Texture\\bomb_cleaned.bmp");

	m_Collider = AddComponent(new Collider);
	m_Collider->SetScale(Vec2(100.f, 100.f)); // �׽�Ʈ ��
	// m_Collider->SetScale(GetScale()); -> �ؽ��� ������ �̰� ����
}

void Bomb::Tick()
{
}


void Bomb::Render(HDC _dc)
{
    if (m_Tex)
    {
        Vec2 renderPos = GetRenderPos();
        float w = m_Tex->GetWidth();
        float h = m_Tex->GetHeight();

        TransparentBlt(_dc,
            (int)(renderPos.x - w / 2.f),
            (int)(renderPos.y - h / 2.f),
            (int)w,
            (int)h,
            m_Tex->GetDC(),
            0, 0,
            (int)w,
            (int)h,
            RGB(255, 0, 255)); // ����Ÿ ����
    }

    Actor::Render(_dc); // ����׿� �ڽ�
}
