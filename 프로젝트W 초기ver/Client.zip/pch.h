#pragma once

#include <windows.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <assert.h>

#include "resource.h"

// WinGDI Library 
#pragma comment(lib, "Msimg32.lib")


// GDI Plus
#include <objidl.h>
#include <gdiplus.h>
#pragma comment(lib, "Gdiplus.lib")
using namespace Gdiplus;

// ����
#include <mmsystem.h>
#include <dsound.h>
#include <dinput.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "dsound.lib")


// �ڷᱸ��
#include <vector>
#include <list>
#include <map>
#include <algorithm>

// ���ڿ�
#include <string>
using namespace std;

// Engine ��ü ���
#include "global.h"