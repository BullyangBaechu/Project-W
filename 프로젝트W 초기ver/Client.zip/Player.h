#pragma once
#include "Actor.h"

class Texture;
class Collider;
class FlipbookPlayer;
class RigidBody;


enum class PLAYER_ANIM
{
    IDLE_UP,
    IDLE_DOWN,
    IDLE_LEFT,
    IDLE_RIGHT,

    MOVE_UP,
    MOVE_DOWN,
    MOVE_LEFT,
    MOVE_RIGHT,
};


class Player :
    public Actor
{
private:
    float           m_Speed;            // �÷��̾��� �̵��ӷ�    
    Texture*        m_Texture;
       
    Collider*       m_HurtBox;
    FlipbookPlayer* m_FBPlayer;
    RigidBody*      m_RigidBody;

    // PlayerAttack ��
    Collider*       m_AttackCollider;   // ���� ���� ��
    float           m_AttackTimer;      // ���� ���� Ÿ�̸�
    int             m_Dmg;              // �÷��̾� ���ݷ�

    Vec2            m_PrevPos;          // ���� ������ ��ġ

    // PlayerGaurd ��

    

    //bool            m_BlockLeft;;
    //bool            m_BlockRight;

public:
    virtual void Tick() override;   
    virtual void Render(HDC _dc) override;
    virtual void BeginOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider) override;
    virtual void EndOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider) override;

    int GetPlayerDmg() { return m_Dmg; }

    virtual bool CamCheck() override;

private:
    void Shoot();
    void PlayerAttack();
    void ChangeFlipbook();
    


public:
    Player();
    ~Player();
};

