#include "pch.h"
#include "Bomb.h"
#include "Engine.h"

#include "Collider.h"
#include "AssetMgr.h"
#include "TimeMgr.h"

void Bomb::Init()
{
	SetName(L"Bomb");

	SetScale(Vec2(120.f, 120.f));
	m_Tex = AssetMgr::GetInst()->LoadTexture(L"bomb", L"Texture\\BombDrone.bmp");

	m_Collider = AddComponent(new Collider);
	m_Collider->SetScale(Vec2(80.f, 80.f)); // �׽�Ʈ ��
	// m_Collider->SetScale(GetScale()); -> �ؽ��� ������ �̰� ����
    m_speed = 600.f;


}

void Bomb::Tick()
{
    if (nullptr == m_Target)
    {
        // ������
        OutputDebugString(L"m_Target is NULL\n");
        return;
    }
    
    Vec2 pPos = m_Target->GetPos(); // �÷��̾� ��ġ
    Vec2 bPos = this->GetPos();     // ��ź ��ġ

    Vec2 Dir = pPos - bPos;

    if (Dir.Length() != 0.f)
    {
        Dir.Normalize();
        bPos += Dir* m_speed * DT;
        SetPos(bPos);
    }
}


void Bomb::Render(HDC _dc)
{
    if (m_Tex)
    {
        Vec2 renderPos = GetRenderPos();
        float w = m_Tex->GetWidth();
        float h = m_Tex->GetHeight();

        TransparentBlt(_dc,
            (int)(renderPos.x - w / 2.f),
            (int)(renderPos.y - h / 2.f),
            (int)w,
            (int)h,
            m_Tex->GetDC(),
            0, 0,
            (int)w,
            (int)h,
            RGB(255, 255, 255)); // ���� ����
    }

    Actor::Render(_dc); // ����׿� �ڽ�
}

void Bomb::BeginOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider)
{
    if (_OtherCollider->GetName() == L"GuardBox" && _OtherCollider->IsEnable())
    {
        Destroy();
    }
}

void Bomb::Overlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider)
{
    if (_OtherCollider->GetName() == L"GuardBox" && _OtherCollider->IsEnable())
    {
        Destroy();
    }
}

void Bomb::EndOverlap(Collider* _Own, Actor* _OtherActor, Collider* _OtherCollider)
{
}
