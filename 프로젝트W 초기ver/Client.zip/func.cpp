#include "pch.h"
#include "func.h"

#include "RenderMgr.h"
void DrawDebugRect(Vec2 _Center, Vec2 _Scale, PEN_TYPE _Pen, float _Life)
{
	tDebugShape shape = {};

	shape.Shape = DEBUG_SHAPE::RECT;
	shape.Center = _Center;
	shape.Scale = _Scale;
	shape.Age = 0.f;
	shape.Life = _Life;
	shape.Pen = _Pen;

	RenderMgr::GetInst()->AddDebugShape(shape);
}

void DrawDebugCircle(Vec2 _Center, float _Radius, PEN_TYPE _Pen, float _Life)
{
	tDebugShape shape = {};

	shape.Shape = DEBUG_SHAPE::CIRCLE;
	shape.Center = _Center;
	shape.Scale = Vec2(_Radius * 2.f, _Radius * 2.f);
	shape.Age = 0.f;
	shape.Life = _Life;
	shape.Pen = _Pen;

	RenderMgr::GetInst()->AddDebugShape(shape);
}

void DrawDebugLine(Vec2 _Start, Vec2 _End, PEN_TYPE _Pen, float _Life)
{
	tDebugShape shape = {};

	shape.Shape = DEBUG_SHAPE::LINE;
	shape.Center = _Start;
	shape.Scale = _End;
	shape.Age = 0.f;
	shape.Life = _Life;
	shape.Pen = _Pen;

	RenderMgr::GetInst()->AddDebugShape(shape);
}

#include "TaskMgr.h"
void CreateActor(ACTOR_TYPE _Type, class Actor* _Actor)
{
	// Task ó��
	tTask task = {};

	task.Type = TASK_TYPE::CREATE_ACTOR;
	task.Param0 = (DWORD_PTR)_Actor;
	task.Param1 = (DWORD_PTR)_Type;

	TaskMgr::GetInst()->AddTask(task);
}

void ChangeLevel(LEVEL_TYPE _Next)
{
	// Task ó��
	tTask task = {};

	task.Type = TASK_TYPE::CHANGE_LEVEL;
	task.Param0 = (DWORD_PTR)_Next;

	TaskMgr::GetInst()->AddTask(task);
}

#include "Actor.h"
bool IsValid(Actor*& _Actor)
{
	if (nullptr == _Actor)
		return false;

	if (_Actor->IsDead())
	{
		_Actor = nullptr;
		return false;
	}

	return true;
}

Vec2 Rotate(Vec2 _Dir, float _Angle)
{
	Vec2 vRotate;

	vRotate.x = cosf(_Angle) * _Dir.x - sinf(_Angle) * _Dir.y;
	vRotate.y = sinf(_Angle) * _Dir.x + cosf(_Angle) * _Dir.y;	

	return vRotate;
}

void StringSave(const wstring& _String, FILE* _File)
{	
	// ���ڿ��� ���� ����
	int Len = (int)_String.length();
	fwrite(&Len, sizeof(int), 1, _File);

	// ���� ���ڿ� ����
	fwrite(_String.c_str(), sizeof(wchar_t), Len, _File);
}

void StringLoad(wstring& _String, FILE* _File)
{
	// ���ڿ� ���� �ҷ�����
	int Len = 0;
	fread(&Len, sizeof(int), 1, _File);

	// ���ڿ� �ҷ�����
	wchar_t szBuffer[255] = {};
	fread(szBuffer, sizeof(wchar_t), (size_t)Len, _File);
	_String = szBuffer;
}

#include "AssetMgr.h"
#include "Asset.h"
void SaveAsset(Asset* _Asset, FILE* _File)
{
	// �����Ͱ� nullptr ���� �ƴ��� ����
	int bAsset = !!_Asset;
	fwrite(&bAsset, sizeof(int), 1, _File);

	if (bAsset)
	{
		// �ؽ��� Ű, ��� ����
		StringSave(_Asset->GetKey(), _File);
		StringSave(_Asset->GetPath(), _File);
	}
}


#include "Texture.h"
#include "Sound.h"
#include "Sprite.h"
#include "Flipbook.h"
Asset* LoadAsset(ASSET_TYPE _Type, FILE* _File)
{
	// �ؽ��İ� nullptr ���� �ƴ��� �ҷ��´�
	int bAsset = 0;
	fread(&bAsset, sizeof(int), 1, _File);

	if (!bAsset)
	{		
		return nullptr;
	}

	// �ؽ��� Ű, ��� �ҷ�����
	wstring Key, Path;

	StringLoad(Key, _File);
	StringLoad(Path, _File);

	switch (_Type)
	{
	case ASSET_TYPE::TEXTURE:
		return AssetMgr::GetInst()->LoadTexture(Key, Path);
	//case ASSET_TYPE::SOUND:
	//	  return AssetMgr::GetInst()->LoadSound(Key, Path);
	case ASSET_TYPE::SPRITE:
		return AssetMgr::GetInst()->LoadSprite(Key, Path);
	case ASSET_TYPE::FLIPBOOK:
		return AssetMgr::GetInst()->LoadFlipbook(Key, Path);
	}

	assert(nullptr);
	return nullptr;
}

void Saturate(float& _Ratio)
{
	if (_Ratio < 0.f)
		_Ratio = 0.f;
	if (1.f < _Ratio)
		_Ratio = 1.f;
}
