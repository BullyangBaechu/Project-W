#include "pch.h"
#include "StartLevel.h"

#include "Camera.h"
#include "KeyMgr.h"
#include "Force.h"

#include "Engine.h"
#include "Level.h"
#include "Player.h"
#include "Monster.h"
#include "TileActor.h"
#include "Ground.h"

#include "CollisionMgr.h"
#include "Camera.h"

StartLevel::StartLevel()
{
}

StartLevel::~StartLevel()
{
}

void StartLevel::Enter()
{
	
}

void StartLevel::Tick()
{
	Level::Tick();

	if (KEY_TAP(KEY::ENTER))
	{
		ChangeLevel(LEVEL_TYPE::RUNNING);
	}

	if (KEY_TAP(KEY::F4))
	{
		ChangeLevel(LEVEL_TYPE::TEST);
	}

	if (KEY_TAP(KEY::F8))
	{
		ChangeLevel(LEVEL_TYPE::INFINITYMODE);
	}

	// ���콺 ��Ŭ���� �߻��ϸ�, �ش���ġ�� Force ��ü�� ������Ŵ
	if (KEY_TAP(KEY::LBTN))
	{
		Force* pForce = new Force;		
		// ���콺�� Ŭ���� ������ ���� ��ǥ�� ����ؼ� ��ġ
		pForce->SetPos(Camera::GetInst()->GetRealPos(KeyMgr::GetInst()->GetMousePos()));
		pForce->SetDuration(0.05f);
		pForce->SetForceScale(1000000.f);
		pForce->SetRange(300.f);
		pForce->SetActorType(ACTOR_TYPE::PLAYER, true);
		pForce->SetActorType(ACTOR_TYPE::ENERMY, true);
		CreateActor(ACTOR_TYPE::FORCE, pForce);
	}
}

void StartLevel::Exit()
{
	DeleteAllObject();
}


